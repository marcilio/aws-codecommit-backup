#!/bin/bash

aws_region="us-east-2"
scripts_s3_bucket="codecommit-backups"
backups_s3_bucket="codecommit-backups"
stack_name="codecommit-backups"

cfn_template="codecommit_backup_cfn_template.yaml"
cfn_parameters="codecommit_backup_cfn_parameters.json"
zipfile="codecommit_backup_scripts.zip"

zip -r "${zipfile}" ./
aws s3 cp "${zipfile}" "s3://${scripts_s3_bucket}"

# aws cloudformation create-stack \
#     --region $aws_region \
#     --stack-name "${stack_name}" \
#     --template-body "file://./${cfn_template}" \
#     --parameters "file://./${cfn_parameters}" \
#     --capabilities CAPABILITY_IAM

